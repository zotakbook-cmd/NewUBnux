window.UBnuxManagerConfig={
  API_URL:"PASTE_YOUR_CURRENT_APPS_SCRIPT_EXEC_URL_HERE",
  PUBLIC_ORIGIN:"https://ubnux.com",
  SESSION_KEY:"ubnuxBusinessManagerSession",
  REQUEST_TIMEOUT:25000
};
